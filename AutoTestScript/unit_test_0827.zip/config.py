#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
@file: config.py.py
@version: 0.0.1
@author: ZHAOGUIBIN424
@time: 2020/8/27 20:00
@software: IntelliJ IDEA
@site: 
"""
# 接口域名
API_DOMAIN = 'http://api.testbitgame.com'
# 获取orderNo接口
API_ORDERS = '/point/auction/pending/orders'
# 交易提交接口？？？
API_TRADE = '/point/auction/trade/save'

# token
TOKEN_ORDER = 'Basic d3d3OjNBVVNYWG9leVdTQ3ZqdmNqb25MdTRXWnZqQTU1VnZMdVEyYlp3YXI2RA=='
TOKEN_TARDE = 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1OTg1NTU0NzksImlhdCI6MTU5ODUxMjI3OSwidXNlcl9uYW1lIjoiMTk4Mjc3Nzk2IiwianRpIjoiZjBjMDU1YzUtZTYyZS00MTU2LTg5YTUtMWJiYWM5YWY4ZTliIiwiY2xpZW50X2lkIjoid3d3Iiwic2NvcGUiOlsidWkiXX0.qCjVBjZvHwz-xOuN4IPjChbnNl0Klcllc2SecYET_1Q'